# kama/commands/cloud.py

from google.cloud import storage
import boto3
import logging

# إعداد سجل الأخطاء
logging.basicConfig(filename='kama_commands.log', level=logging.ERROR)


def upload_to_gcloud(bucket_name, file_path, **kwargs):
    """
    رفع ملف إلى Google Cloud Storage.
    """
    try:
        client = storage.Client()
        bucket = client.bucket(bucket_name)
        blob = bucket.blob(file_path)
        blob.upload_from_filename(file_path)
        upload_url = blob.public_url
        print(f"File uploaded to Google Cloud Storage: {upload_url}")
        return upload_url
    except Exception as e:
        logging.error(f"Error uploading to Google Cloud: {str(e)}")
        return None

def upload_to_aws(bucket_name, file_path, **kwargs):
    """
    رفع ملف إلى Amazon S3.
    """
    try:
        s3 = boto3.client('s3')
        s3.upload_file(file_path, bucket_name, file_path)
        upload_url = f"https://{bucket_name}.s3.amazonaws.com/{file_path}"
        print(f"File uploaded to Amazon S3: {upload_url}")
        return upload_url
    except Exception as e:
        logging.error(f"Error uploading to AWS S3: {str(e)}")
        return None