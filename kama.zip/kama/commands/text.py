# kama/commands/text.py

import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import gensim
from transformers import pipeline
import logging

# تنزيل الموارد المطلوبة لمكتبة NLTK
try:
    nltk.data.find("tokenizers/punkt")
except LookupError:
    nltk.download("punkt")
try:
    nltk.data.find("corpora/stopwords")
except LookupError:
     nltk.download("stopwords")
# إعداد سجل الأخطاء
logging.basicConfig(filename='kama_commands.log', level=logging.ERROR)


def tokenize_text(text, tokenizer, **kwargs):
    """
    تقطيع النصوص إلى كلمات (tokens) باستخدام أساليب تقطيع مختلفة.
    """
    try:
        if tokenizer == 'nltk':
          tokens = word_tokenize(text)
        else:
             raise ValueError(f"Tokenizer '{tokenizer}' not supported!")
        print("Text tokenized successfully!")
        return tokens
    except Exception as e:
          logging.error(f"Error tokenizing text: {str(e)}")
          return None


def remove_stopwords(tokens, language, **kwargs):
     """
     إزالة الكلمات الشائعة (stop words) من قائمة الكلمات.
     """
     try:
          stop_words = set(stopwords.words(language))
          filtered_tokens = [token for token in tokens if token.lower() not in stop_words]
          print("Stop words removed successfully!")
          return filtered_tokens
     except Exception as e:
          logging.error(f"Error removing stop words: {str(e)}")
          return None


def create_word_embeddings(text, embedding_type, **kwargs):
    """
    إنشاء تمثيلات متجهية للكلمات (word embeddings) باستخدام أنواع مختلفة من النماذج.
    """
    try:
       tokens = tokenize_text(text, tokenizer='nltk')
       if embedding_type == 'word2vec':
         model = gensim.models.Word2Vec([tokens], vector_size=100, window=5, min_count=1, sg=0)
       elif embedding_type == 'glove':
         # Here we can add the glove model downloading function
         raise NotImplementedError("Glove model is not implemented yet, Please try to use word2vec")
       else:
            raise ValueError(f"Embedding type '{embedding_type}' not supported!")
       word_vectors = {word: model.wv[word] for word in tokens}
       print("Word embeddings created successfully!")
       return word_vectors
    except Exception as e:
          logging.error(f"Error creating word embeddings: {str(e)}")
          return None


def sentiment_analysis(text, model_name='sentiment-analysis', **kwargs):
    """
    تحليل المشاعر في النص باستخدام نماذج مدربة مسبقًا.
    """
    try:
        model = pipeline(model_name)
        result = model(text)
        print("Sentiment analysis performed successfully!")
        return result
    except Exception as e:
        logging.error(f"Error performing sentiment analysis: {str(e)}")
        return None