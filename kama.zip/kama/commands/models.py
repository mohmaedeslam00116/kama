# kama/commands/models.py

import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Flatten
import logging
import pickle
from sklearn.model_selection import  GridSearchCV
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

# إعداد سجل الأخطاء
logging.basicConfig(filename='kama_commands.log', level=logging.ERROR)


def train_model(model, data, **kwargs):
    """
    تدريب نموذج التعلم الآلي.
    """
    try:
        epochs = kwargs.get('epochs', 10)
        model.fit(data[0], data[1], epochs=epochs)
        print("Model trained successfully!")
        return model
    except Exception as e:
        logging.error(f"Error training model: {str(e)}")
        return None


def evaluate_model(model, data, **kwargs):
    """
    تقييم أداء النموذج.
    """
    try:
        loss, accuracy = model.evaluate(data[0], data[1])
        print(f"Loss: {loss}, Accuracy: {accuracy}")
        return loss, accuracy
    except Exception as e:
        logging.error(f"Error evaluating model: {str(e)}")
        return None


def save_model(model, file_path, **kwargs):
    """
    حفظ النموذج المدرب.
    """
    try:
      with open(file_path, 'wb') as file:
          pickle.dump(model, file)
      print(f"Model saved to {file_path} successfully!")
      return file_path
    except Exception as e:
        logging.error(f"Error saving the model: {str(e)}")
        return None

def load_model(file_path, **kwargs):
    """
    تحميل نموذج محفوظ.
    """
    try:
        with open(file_path, 'rb') as file:
           model = pickle.load(file)
        print(f"Model loaded from {file_path} successfully!")
        return model
    except Exception as e:
        logging.error(f"Error loading model from {file_path}: {str(e)}")
        return None

def predict(model, data, **kwargs):
    """
    عمل تنبؤات باستخدام النموذج.
    """
    try:
        predictions = model.predict(data)
        print("Predictions generated successfully!")
        return predictions
    except Exception as e:
        logging.error(f"Error generating prediction: {str(e)}")
        return None


def train_dnn(data, model_type, hyperparams, **kwargs):
    """
    تدريب نموذج شبكة عصبونية عميقة.
    """
    try:
      x_train, y_train = data
      if model_type == 'simple_dnn':
          model = Sequential([
              Flatten(input_shape=x_train.shape[1:]),
              Dense(128, activation='relu'),
              Dense(len(np.unique(y_train)), activation='softmax')
          ])
          model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
      else:
          raise ValueError(f"Model type '{model_type}' not supported")

      epochs = hyperparams.get('epochs', 10)
      batch_size = hyperparams.get('batch_size', 32)
      model.fit(x_train, y_train, epochs=epochs, batch_size=batch_size)
      print("DNN model trained successfully!")
      return model
    except Exception as e:
        logging.error(f"Error training DNN model: {str(e)}")
        return None

def train_traditional_model(data, model_type, hyperparams, **kwargs):
      """
      تدريب نموذج تعلم الآلة التقليدي.
      """
      try:
            x_train, y_train = data
            if model_type == 'linear_regression':
                  model = LinearRegression()
            elif model_type == 'decision_tree':
                  model = DecisionTreeClassifier(random_state = hyperparams.get('random_state',42), max_depth = hyperparams.get('max_depth', None))
            elif model_type == 'random_forest':
                model = RandomForestClassifier(random_state = hyperparams.get('random_state',42), n_estimators = hyperparams.get('n_estimators', 100), max_depth = hyperparams.get('max_depth', None))
            else:
              raise ValueError(f"Model type '{model_type}' not supported")

            model.fit(x_train, y_train)
            print(f"{model_type} model trained successfully!")
            return model
      except Exception as e:
            logging.error(f"Error training {model_type} model: {str(e)}")
            return None

def tune_model(data, model, param_grid, cv=3, **kwargs):
    """
      ضبط معلمات النموذج.
      """
    try:
        x_train, y_train = data
        grid = GridSearchCV(model, param_grid, cv=cv)
        grid.fit(x_train, y_train)
        print("Model tuned successfully!")
        return grid.best_estimator_
    except Exception as e:
        logging.error(f"Error tuning the model: {str(e)}")
        return None