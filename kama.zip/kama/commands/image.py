# kama/commands/image.py
from PIL import Image, ImageFilter
import cv2
import numpy as np
from transformers import pipeline
import logging

# إعداد سجل الأخطاء
logging.basicConfig(filename='kama_commands.log', level=logging.ERROR)


def load_image(image_path, **kwargs):
      """
      تحميل صورة من مسار معين.

       Args:
        image_path (str): مسار الصورة المراد تحميلها.
        **kwargs: وسائط إضافية.

       Returns:
        Image: الصورة المحملة أو None في حالة الخطأ.
      """
      try:
          image = Image.open(image_path)
          print("Image loaded successfully!")
          return image
      except Exception as e:
          logging.error(f"Error loading image: {str(e)}")
          return None


def resize_image(image, size, **kwargs):
      """
      تغيير حجم الصورة.

      Args:
          image: الصورة المراد تغيير حجمها.
          size (tuple): حجم الصورة الجديد (على شكل `(height, width)`).
          **kwargs: وسائط إضافية.

      Returns:
         Image: الصورة بعد تغيير حجمها أو None في حالة الخطأ.
      """
      try:
            resized_image = image.resize(size)
            print("Image resized successfully!")
            return resized_image
      except Exception as e:
          logging.error(f"Error resizing image: {str(e)}")
          return None


def apply_filter(image, filter_type, **kwargs):
     """
     تطبيق فلتر على الصورة.

     Args:
         image: الصورة المراد تطبيق الفلتر عليها.
         filter_type (str): نوع الفلتر (grayscale, blur, edge_detection).
         **kwargs: وسائط إضافية.

     Returns:
         Image: الصورة بعد تطبيق الفلتر أو None في حالة الخطأ.
     """
     try:
          if filter_type == 'grayscale':
               filtered_image = image.convert('L')
          elif filter_type == 'blur':
               filtered_image = image.filter(ImageFilter.BLUR)
          elif filter_type == 'edge_detection':
               filtered_image = image.filter(ImageFilter.FIND_EDGES)
          else:
               raise ValueError(f"Filter type '{filter_type}' not supported!")

          print("Filter applied successfully!")
          return filtered_image
     except Exception as e:
           logging.error(f"Error applying filter: {str(e)}")
           return None

def detect_objects(image, model_name='yolov8', **kwargs):
    """
    الكشف عن الأجسام في الصورة باستخدام نماذج مدربة مسبقًا.

    Args:
        image: الصورة المراد الكشف عن الأجسام فيها.
        model_name (str): اسم النموذج المراد استخدامه (yolov8).
        **kwargs: وسائط إضافية.

     Returns:
        list: قائمة بالكائنات المكتشفة (bbox, label, confidence) أو None في حالة الخطأ.
    """
    try:
      if model_name == 'yolov8':
        # Convert PIL Image to OpenCV format
         image_np = np.array(image)
         image_cv = cv2.cvtColor(image_np, cv2.COLOR_RGB2BGR)
        # Load YOLOv8 model
         model = pipeline(task="object-detection", model="hustvl/yolov8")
        # Perform object detection
         detections = model(image_cv)
         print("Object detection performed successfully!")
         return detections
      else:
         raise ValueError(f"Model '{model_name}' not supported!")
    except Exception as e:
         logging.error(f"Error performing object detection: {str(e)}")
         return None