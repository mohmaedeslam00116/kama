# kama/commands/data.py

import numpy as np
import pandas as pd
from tensorflow.keras.datasets import mnist
import tensorflow as tf
import matplotlib.pyplot as plt
import logging
# إعداد سجل الأخطاء
logging.basicConfig(filename='kama_commands.log', level=logging.ERROR)


def load_data(dataset_name, **kwargs):
    """
    تحميل بيانات من مصادر مختلفة.
    """
    try:
        if dataset_name.lower() == "mnist":
            (x_train, y_train), (x_test, y_test) = mnist.load_data()
            print("MNIST data loaded successfully!")
            return (x_train, y_train), (x_test, y_test)
        else:
            raise ValueError(f"Dataset '{dataset_name}' not supported!")
    except Exception as e:
        logging.error(f"Error loading data: {str(e)}")
        return None


def load_large_data(file_path, **kwargs):
    """
    تحميل بيانات كبيرة على شكل أجزاء.
    """
    try:
        chunksize = kwargs.get('chunksize', 10000)
        data = pd.read_csv(file_path, chunksize=chunksize)
        print("Large data loaded!")
        return data
    except Exception as e:
        logging.error(f"Error loading large data: {str(e)}")
        return None

def process_large_data(data_chunks, **kwargs):
    """
    معالجة البيانات الكبيرة.
    """
    try:
        processed_data = pd.concat(data_chunks, ignore_index=True)
        print("Large data processed!")
        return processed_data
    except Exception as e:
        logging.error(f"Error processing large data: {str(e)}")
        return None


def get_data_shape(data, **kwargs):
    """
    الحصول على أبعاد البيانات.
    """
    try:
        shape = data.shape
        print(f"Data shape: {shape}")
        return shape
    except Exception as e:
        logging.error(f"Error getting data shape: {str(e)}")
        return None

def plot_data(data, plot_type='line', **kwargs):
    """
    رسم البيانات بأنواع مختلفة من الرسوم البيانية.
    """
    try:
        plt.figure()
        if plot_type == 'line':
            plt.plot(data)
        elif plot_type == 'hist':
            plt.hist(data)
        elif plot_type == 'scatter':
            if data.shape[1] == 2:
                 plt.scatter(data[:,0], data[:,1])
            else:
                raise ValueError("Scatter plot needs two dimensions")
        else:
            raise ValueError(f"Plot type '{plot_type}' not supported!")

        plt.title(f'{plot_type.capitalize()} Plot')
        plt.xlabel('X Axis')
        plt.ylabel('Y Axis')
        plt.grid(True)
        plt.show()
        print("Data plotted successfully!")
        return "Plot generated successfully"

    except Exception as e:
        logging.error(f"Error plotting data: {str(e)}")
        return None

def convert_to_tensor(data, **kwargs):
    """
    تحويل البيانات إلى تنسور.
    """
    try:
        tensor = tf.convert_to_tensor(data)
        print("Data converted to tensor successfully!")
        return tensor
    except Exception as e:
        logging.error(f"Error converting data to tensor: {str(e)}")
        return None

def clean_data(data, strategy, **kwargs):
      """
      تنظيف البيانات باستخدام استراتيجيات مختلفة.
      """
      try:
            df = pd.DataFrame(data)
            if strategy == 'drop_na':
                cleaned_data = df.dropna()
            elif strategy == 'fill_mean':
                  cleaned_data = df.fillna(df.mean(numeric_only=True))
            elif strategy == 'drop_duplicates':
                cleaned_data = df.drop_duplicates()
            else:
                raise ValueError(f"Invalid cleaning strategy: {strategy}")
            print("Data cleaned successfully!")
            return cleaned_data
      except Exception as e:
             logging.error(f"Error cleaning data: {str(e)}")
             return None


def transform_data(data, transformations, **kwargs):
    """
    تحويل البيانات باستخدام تحويلات مختلفة.
    """
    try:
        df = pd.DataFrame(data)
        transformed_data = df.copy()
        for transformation in transformations:
            if transformation == 'scale':
                scaler = StandardScaler()
                transformed_data[transformed_data.select_dtypes(include=np.number).columns] = scaler.fit_transform(transformed_data.select_dtypes(include=np.number))
            elif transformation == 'normalize':
                transformed_data[transformed_data.select_dtypes(include=np.number).columns] = transformed_data[transformed_data.select_dtypes(include=np.number).columns] / np.linalg.norm(transformed_data[transformed_data.select_dtypes(include=np.number).columns], axis=0)
            elif transformation == 'encode_categorical':
                  encoder = OneHotEncoder()
                  categorical_cols = df.select_dtypes(include=['object']).columns
                  encoded_data = encoder.fit_transform(df[categorical_cols]).toarray()
                  encoded_df = pd.DataFrame(encoded_data, columns=encoder.get_feature_names_out(categorical_cols))
                  transformed_data = pd.concat([transformed_data.drop(categorical_cols, axis=1),encoded_df], axis=1)

            else:
                raise ValueError(f"Invalid transformation: {transformation}")
        print("Data transformed successfully!")
        return transformed_data
    except Exception as e:
        logging.error(f"Error transforming data: {str(e)}")
        return None

def split_data(data, test_size=0.2, random_state=None, **kwargs):
    """
    تقسيم البيانات إلى مجموعات تدريب واختبار.
    """
    try:
        df = pd.DataFrame(data)
        if 'target' not in df.columns:
            raise ValueError("The target column should be available in the data or please define the column by passing the target_column argument")
        target_column = kwargs.get('target_column','target')
        x = df.drop(columns=[target_column])
        y = df[target_column]

        x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=test_size, random_state=random_state)
        print("Data split successfully!")
        return x_train, x_test, y_train, y_test
    except Exception as e:
        logging.error(f"Error splitting data: {str(e)}")
        return None


def group_data(data, by_columns, aggregations, **kwargs):
    """
    تجميع البيانات بناءً على أعمدة معينة وتطبيق عمليات تجميع.
    """
    try:
        df = pd.DataFrame(data)
        grouped_data = df.groupby(by_columns).agg(aggregations)
        print("Data grouped successfully!")
        return grouped_data
    except Exception as e:
        logging.error(f"Error grouping data: {str(e)}")
        return None