# kama/core.py

import ast
import logging

# إعداد سجل الأخطاء
logging.basicConfig(filename='kama_errors.log', level=logging.ERROR)

class Kama:
    def __init__(self):
        self.context = {}

    def execute(self, code, context=None):
        """
        تنفيذ كود بلغة Kama.

        Args:
            code (str): الكود المراد تنفيذه.
            context (dict, optional): سياق التنفيذ. Defaults to None.

        Returns:
            str: رسالة نجاح أو خطأ.
        """
        local_context = context if context else self.context
        try:
            # تحليل الكود بأمان
            tree = ast.parse(code, mode='exec')
            exec(compile(tree, filename="<ast>", mode="exec"), local_context)
            return "Code executed successfully!"
        except SyntaxError as e:
            logging.error(f"Syntax error: {str(e)}")
            return f"Syntax error: {str(e)}"
        except Exception as e:
            logging.error(f"Execution error: {str(e)}")
            return f"Execution error: {str(e)}"