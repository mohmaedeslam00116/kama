# kama/utils.py

import os
import numpy as np
import streamlit as st

def validate_file_path(file_path):
    """
    التحقق من أن مسار الملف صالح.

    Args:
        file_path (str): مسار الملف المراد التحقق منه.

    Returns:
        bool: True إذا كان مسار الملف صالحًا، False إذا لم يكن كذلك.
    """
    if not file_path:
        return False
    return os.path.exists(file_path)


def convert_to_numpy(data):
    """
    تحويل البيانات إلى مصفوفة NumPy إذا لم تكن كذلك بالفعل.

    Args:
        data (any): البيانات المراد تحويلها.

    Returns:
         array: البيانات المحولة إلى مصفوفة NumPy أو البيانات الأصلية إذا كانت بالفعل مصفوفة.
    """
    if isinstance(data, np.ndarray):
        return data
    try:
        return np.array(data)
    except Exception:
        return data


def display_message(message, type='info'):
    """
    عرض رسائل المستخدم بتنسيقات مختلفة باستخدام Streamlit.

    Args:
        message (str): الرسالة المراد عرضها.
        type (str, optional): نوع الرسالة (info, success, warning, error). Defaults to 'info'.
    """
    if type == 'info':
        st.info(message)
    elif type == 'success':
        st.success(message)
    elif type == 'warning':
        st.warning(message)
    elif type == 'error':
        st.error(message)
    else:
        st.write(message)

def preprocess_text(text):
    """
      معالجة النصوص.

    Args:
        text (str): النصوص المراد معالجتها.

    Returns:
        str: النصوص المعالجة.
    """
    # هنا يمكنك إضافة وظائف لمعالجة النصوص مثل:
    # 1.  تحويل النص إلى حروف صغيرة
    # 2. إزالة علامات الترقيم
    # 3. إزالة الكلمات الشائعة
    # 4. التقطيع
    return text.lower()