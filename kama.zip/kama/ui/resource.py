# kama/ui/resource.py
import streamlit as st
from kama.core.kama import Kama
from kama.utils.helpers import display_message

kama_lang = Kama()

def resource_management_ui():
    st.header("Resource Management")
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Use GPU"):
            with st.spinner("Activating GPU..."):
                device = kama_lang.context['use_gpu']()
                st.write(device)
    with col2:
        if st.button("Use TPU"):
            with st.spinner("Activating TPU..."):
                device = kama_lang.context['use_tpu']()
                st.write(device)