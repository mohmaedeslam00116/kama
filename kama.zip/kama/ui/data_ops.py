# kama/ui/data_ops.py
import streamlit as st
from kama.core.kama import Kama
from kama.utils.helpers import convert_to_numpy, display_message
kama_lang = Kama()

def data_shape_ui():
    st.header("Get Data Shape")
    with st.form("shape_form"):
        data_input = st.text_input("Enter your Data (e.g., [1, 2, 3] for list or [[1,2], [3,4]] for nested list):")
        submitted = st.form_submit_button("Get Shape")
    if submitted and data_input:
         try:
            data = eval(data_input)
            data = convert_to_numpy(data)
            with st.spinner("Getting Data Shape..."):
                shape = kama_lang.context['get_data_shape'](data)
                st.write(f"Data shape: {shape}")
         except Exception as e:
            display_message(f"Error processing input: {str(e)}", type='error')

def data_plot_ui():
    st.header("Plot Data")
    with st.form("plot_form"):
        data_input = st.text_input("Enter data to plot (e.g., [1, 2, 3] for list or [[1,2], [3,4]] for nested list):")
        plot_type = st.selectbox("Select plot type", ["line", "hist", "scatter"])
        submitted = st.form_submit_button("Plot Data")
    if submitted and data_input:
          try:
               data = eval(data_input)
               data = convert_to_numpy(data)
               with st.spinner("Plotting Data..."):
                   plot = kama_lang.context['plot_data'](data, plot_type)
                   st.session_state.plotted_data = plot
                   display_message("Data Plotted Successfully", type='success')
          except Exception as e:
             display_message(f"Error processing input: {str(e)}", type='error')
    if st.session_state.plotted_data is not None:
        st.write(st.session_state.plotted_data)

def data_tensor_ui():
    st.header("Convert Data to Tensor")
    with st.form("tensor_form"):
        data_input = st.text_input("Enter data to convert (e.g., [1, 2, 3] for list or [[1,2], [3,4]] for nested list):")
        submitted = st.form_submit_button("Convert to Tensor")
    if submitted and data_input:
         try:
               data = eval(data_input)
               data = convert_to_numpy(data)
               with st.spinner("Converting to tensor..."):
                     tensor = kama_lang.context['convert_to_tensor'](data)
                     st.session_state.tensor_data = tensor
                     display_message("Data Converted Successfully", type='success')
         except Exception as e:
              display_message(f"Error processing input: {str(e)}", type='error')
    if st.session_state.tensor_data is not None:
        st.write("Tensor Data:", st.session_state.tensor_data)

def data_clean_ui():
    st.header("Clean Data")
    with st.form("clean_form"):
        data_input = st.text_input("Enter your Data (e.g., [[1,2,None], [3,4,5], [1,2,None]]):")
        strategy = st.selectbox("Select cleaning strategy", ["drop_na", "fill_mean", "drop_duplicates"])
        submitted = st.form_submit_button("Clean Data")
    if submitted and data_input:
        try:
              data = eval(data_input)
              data = convert_to_numpy(data)
              with st.spinner("Cleaning Data..."):
                    cleaned_data = kama_lang.context['clean_data'](data, strategy)
                    st.session_state.cleaned_data = cleaned_data
                    display_message("Data Cleaned Successfully", type='success')
        except Exception as e:
              display_message(f"Error processing input: {str(e)}", type='error')
    if st.session_state.cleaned_data is not None:
        st.write("Cleaned Data:", st.session_state.cleaned_data)

def data_transform_ui():
     st.header("Transform Data")
     with st.form("transform_form"):
         data_input = st.text_input("Enter your data (e.g., [[1,2], [3,4]] or [[1,2, 'A'], [3,4, 'B']]):")
         transformations = st.multiselect("Select transformations", ["scale", "normalize", "encode_categorical"])
         submitted = st.form_submit_button("Transform Data")
     if submitted and data_input:
           try:
                data = eval(data_input)
                data = convert_to_numpy(data)
                with st.spinner("Transforming data..."):
                    transformed_data = kama_lang.context['transform_data'](data, transformations)
                    st.session_state.transformed_data = transformed_data
                    display_message("Data Transformed Successfully", type='success')
           except Exception as e:
               display_message(f"Error processing input: {str(e)}", type='error')
     if st.session_state.transformed_data is not None:
        st.write("Transformed Data:", st.session_state.transformed_data)

def data_split_ui():
    st.header("Split Data")
    with st.form("split_form"):
          data_input = st.text_input("Enter your Data with a Target column (e.g., [[1,2, 0], [3,4,1], [1,2,0], [3,4,1]], Target column is 2):")
          test_size = st.number_input("Enter test size (e.g., 0.2):", min_value=0.0, max_value=1.0, value=0.2)
          random_state = st.number_input("Enter random state (e.g., 42):", value=None)
          target_column = st.number_input("Enter target column index:", value = None)
          submitted = st.form_submit_button("Split Data")
    if submitted and data_input:
          try:
               data = eval(data_input)
               data = convert_to_numpy(data)
               if target_column is not None:
                 target_column = int(target_column)
               with st.spinner("Splitting data..."):
                     x_train, x_test, y_train, y_test = kama_lang.context['split_data'](data, test_size, random_state, target_column = target_column)
                     st.session_state.x_train = x_train
                     st.session_state.x_test = x_test
                     st.session_state.y_train = y_train
                     st.session_state.y_test = y_test
                     display_message("Data Splitted Successfully", type='success')
          except Exception as e:
              display_message(f"Error processing input: {str(e)}", type='error')
    if st.session_state.x_train is not None:
         st.write("X Train Data:", st.session_state.x_train)
    if st.session_state.x_test is not None:
         st.write("X Test Data:", st.session_state.x_test)
    if st.session_state.y_train is not None:
        st.write("Y Train Data:", st.session_state.y_train)
    if st.session_state.y_test is not None:
        st.write("Y Test Data:", st.session_state.y_test)

def data_group_ui():
    st.header("Group Data")
    with st.form("group_form"):
        data_input = st.text_input("Enter data to group (e.g., [['A', 1, 5], ['A', 2, 6], ['B', 3, 7], ['B', 4, 8]]):")
        by_columns_input = st.text_input("Enter column indices to group by (e.g., '0' or '0,1'):")
        aggregations_input = st.text_input("Enter aggregations as a dict (e.g., {'1': 'mean', '2': 'sum'})")
        submitted = st.form_submit_button("Group Data")
    if submitted and data_input:
         try:
               data = eval(data_input)
               data = convert_to_numpy(data)
               by_columns = [int(c) for c in by_columns_input.split(',')]
               aggregations = eval(aggregations_input)
               with st.spinner("Grouping data..."):
                   grouped_data = kama_lang.context['group_data'](data, by_columns, aggregations)
                   st.session_state.grouped_data = grouped_data
                   display_message("Data Grouped Successfully", type='success')
         except Exception as e:
               display_message(f"Error processing input: {str(e)}", type='error')
    if st.session_state.grouped_data is not None:
         st.write("Grouped Data:", st.session_state.grouped_data)