# kama/ui/models.py
import streamlit as st
from kama.core.kama import Kama
from kama.utils.helpers import validate_file_path, display_message

kama_lang = Kama()

def pretrained_models_ui():
    st.header("Pre-trained Models")
    with st.form("pretrained_form"):
         model_name = st.text_input("Pre-trained model name:")
         submitted = st.form_submit_button("Submit")
    if submitted and model_name:
        if st.button("Get Model"):
             with st.spinner("Loading pre-trained model..."):
                  model = kama_lang.context['get_pretrained_model'](model_name)
                  st.write(f"Pre-trained model {model_name} loaded successfully!")

def model_management_ui():
    st.header("Model Management")
    with st.form("model_form"):
        model_file_path = st.text_input("Model file path:")
        submitted = st.form_submit_button("Submit")
    if submitted and model_file_path:
        if not validate_file_path(model_file_path):
            display_message("Invalid model file path.", type='error')
            return
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Save Model"):
                with st.spinner("Saving Model..."):
                   if 'model' in st.session_state:
                      file_path = kama_lang.context['save_model'](st.session_state.model,model_file_path)
                      st.write(f"Model Saved To: {file_path}")
                      display_message(f"Model Saved To: {file_path}", type='success')
                   else:
                         display_message("No model trained yet", type='warning')
            with col2:
                if st.button("Load Model"):
                    with st.spinner("Loading Model..."):
                       model = kama_lang.context['load_model'](model_file_path)
                       st.session_state.loaded_model = model
                       display_message("Model loaded successfully!", type='success')
    if st.session_state.loaded_model is not None:
          st.write("Loaded Model:",st.session_state.loaded_model)