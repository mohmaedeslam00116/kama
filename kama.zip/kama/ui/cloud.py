# kama/ui/cloud.py
import streamlit as st
from kama.core.kama import Kama
from kama.utils.helpers import validate_file_path, display_message

kama_lang = Kama()

def cloud_upload_ui():
    st.header("Cloud Upload")
    with st.form("cloud_form"):
        bucket_name = st.text_input("Bucket name:")
        file_path = st.text_input("File path to upload:")
        submitted = st.form_submit_button("Submit")
    if submitted and bucket_name and file_path:
        if not validate_file_path(file_path):
            display_message("Invalid file path.", type='error')
            return
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Upload to Google Cloud"):
                with st.spinner("Uploading to Google Cloud..."):
                    upload_url = kama_lang.context['upload_to_gcloud'](bucket_name, file_path)
                    st.write(f"File uploaded to: {upload_url}")
        with col2:
            if st.button("Upload to Amazon S3"):
               with st.spinner("Uploading to Amazon S3..."):
                    upload_url = kama_lang.context['upload_to_aws'](bucket_name, file_path)
                    st.write(f"File uploaded to: {upload_url}")