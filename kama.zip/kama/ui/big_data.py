# kama/ui/big_data.py
import streamlit as st
from kama.core.kama import Kama
from kama.utils.helpers import validate_file_path, display_message

kama_lang = Kama()

def big_data_processing_ui():
    st.header("Big Data Processing")
    with st.form("big_data_form"):
        file_path = st.text_input("Large data file path:")
        submitted = st.form_submit_button("Submit")
    if submitted and file_path:
        if not validate_file_path(file_path):
            display_message("Invalid file path.", type='error')
            return
        if st.button("Load Large Data"):
            with st.spinner("Loading large data..."):
                st.session_state.data_chunks = kama_lang.context['load_large_data'](file_path)
                display_message("Large data loaded!", type='success')
        if st.session_state.data_chunks:
             if st.button("Process Large Data"):
                  with st.spinner("Processing large data..."):
                         st.session_state.processed_data = kama_lang.context['process_large_data'](st.session_state.data_chunks)
                         display_message("Large data processed!", type='success')
    if st.session_state.processed_data is not None:
        st.write("Processed Data :",st.session_state.processed_data)