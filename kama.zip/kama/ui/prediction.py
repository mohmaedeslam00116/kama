# kama/ui/prediction.py
import streamlit as st
from kama.core.kama import Kama
from kama.utils.helpers import convert_to_numpy, display_message

kama_lang = Kama()

def prediction_ui():
    st.header("Prediction")
    if st.session_state.loaded_model is not None:
        with st.form("prediction_form"):
              data_input = st.text_input("Enter data for prediction (e.g., [1, 2, 3] for list or [[1,2], [3,4]] for nested list):")
              submitted = st.form_submit_button("Predict")
              if submitted and data_input:
                  try:
                       data = eval(data_input)
                       data = convert_to_numpy(data)
                       with st.spinner("Generating predictions..."):
                           predictions = kama_lang.context['predict'](st.session_state.loaded_model, data)
                           st.write("Predictions:", predictions)
                  except Exception as e:
                    display_message(f"Error processing input: {str(e)}", type='error')
    else:
        display_message("No model loaded yet", type='warning')