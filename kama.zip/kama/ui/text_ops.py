# kama/ui/text_ops.py
import streamlit as st
from kama.core.kama import Kama
from kama.utils.helpers import display_message

kama_lang = Kama()

def tokenize_text_ui():
      st.header("Tokenize Text")
      with st.form("tokenize_form"):
            text_input = st.text_area("Enter your text to tokenize:")
            tokenizer = st.selectbox("Select tokenizer", ["nltk"])
            submitted = st.form_submit_button("Tokenize")
      if submitted and text_input:
           try:
                with st.spinner("Tokenizing text..."):
                     tokens = kama_lang.context['tokenize_text'](text_input, tokenizer)
                     st.session_state.tokens = tokens
                     display_message("Text tokenized successfully!", type='success')
           except Exception as e:
                display_message(f"Error processing input: {str(e)}", type='error')
      if st.session_state.tokens is not None:
        st.write("Tokens:", st.session_state.tokens)

def remove_stopwords_ui():
    st.header("Remove Stop Words")
    if st.session_state.tokens is not None:
      with st.form("remove_stopwords_form"):
            language = st.selectbox("Select language", ["english", "arabic"])
            submitted = st.form_submit_button("Remove Stop Words")
      if submitted:
          try:
                with st.spinner("Removing stop words..."):
                      filtered_tokens = kama_lang.context['remove_stopwords'](st.session_state.tokens, language)
                      st.session_state.filtered_tokens = filtered_tokens
                      display_message("Stop words removed successfully!", type='success')
          except Exception as e:
                display_message(f"Error processing input: {str(e)}", type='error')
      if st.session_state.filtered_tokens is not None:
          st.write("Filtered Tokens:", st.session_state.filtered_tokens)
    else:
      display_message("Please tokenize text first", type='warning')

def create_word_embeddings_ui():
     st.header("Create Word Embeddings")
     with st.form("word_embeddings_form"):
          text_input = st.text_area("Enter your text to create embeddings:")
          embedding_type = st.selectbox("Select embedding type", ["word2vec"])
          submitted = st.form_submit_button("Create Embeddings")
     if submitted and text_input:
          try:
              with st.spinner("Creating word embeddings..."):
                  embeddings = kama_lang.context['create_word_embeddings'](text_input, embedding_type)
                  st.session_state.word_embeddings = embeddings
                  display_message("Word embeddings created successfully!", type='success')
          except Exception as e:
              display_message(f"Error processing input: {str(e)}", type='error')
     if st.session_state.word_embeddings is not None:
          st.write("Word Embeddings:", st.session_state.word_embeddings)

def sentiment_analysis_ui():
    st.header("Sentiment Analysis")
    with st.form("sentiment_form"):
        text_input = st.text_area("Enter your text for sentiment analysis:")
        submitted = st.form_submit_button("Analyze Sentiment")
    if submitted and text_input:
        try:
            with st.spinner("Analyzing sentiment..."):
                result = kama_lang.context['sentiment_analysis'](text_input)
                st.session_state.sentiment_result = result
                display_message("Sentiment analysis performed successfully!", type='success')
        except Exception as e:
            display_message(f"Error processing input: {str(e)}", type='error')
    if st.session_state.sentiment_result is not None:
         st.write("Sentiment Analysis Result:", st.session_state.sentiment_result)