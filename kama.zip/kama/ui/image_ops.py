# kama/ui/image_ops.py
import streamlit as st
from kama.core.kama import Kama
from kama.utils.helpers import display_message
from PIL import Image

kama_lang = Kama()

def image_processing_ui():
    st.header("Image Processing")
    with st.form("image_form"):
        image_path = st.text_input("Enter image path:")
        submitted = st.form_submit_button("Submit")
    if submitted and image_path:
         if st.button("Load Image"):
             with st.spinner("Loading image..."):
                try:
                    image = kama_lang.context['load_image'](image_path)
                    st.session_state.loaded_image = image
                    display_message("Image loaded successfully!", type='success')
                except Exception as e:
                    display_message(f"Error loading image: {str(e)}", type='error')

    if st.session_state.loaded_image is not None:
        st.image(st.session_state.loaded_image, caption="Loaded Image")
        col1, col2 = st.columns(2)
        with col1:
            with st.form("resize_form"):
                 size_input = st.text_input("Enter new size (e.g., 100,50):")
                 submitted = st.form_submit_button("Resize Image")
            if submitted and size_input:
                try:
                    size = tuple(map(int, size_input.split(',')))
                    if len(size) != 2:
                        raise ValueError("Size input must be two numbers separated by a comma")
                    with st.spinner("Resizing image..."):
                         resized_image = kama_lang.context['resize_image'](st.session_state.loaded_image, size)
                         st.session_state.resized_image = resized_image
                         display_message("Image resized successfully!", type='success')
                except Exception as e:
                    display_message(f"Error resizing image: {str(e)}", type='error')
            if 'resized_image' in st.session_state and st.session_state.resized_image is not None:
                st.image(st.session_state.resized_image, caption="Resized Image")
        with col2:
            with st.form("filter_form"):
                  filter_type = st.selectbox("Select filter type", ["grayscale", "blur", "edge_detection"])
                  submitted = st.form_submit_button("Apply Filter")
            if submitted:
                try:
                    with st.spinner("Applying filter..."):
                        filtered_image = kama_lang.context['apply_filter'](st.session_state.resized_image if 'resized_image' in st.session_state and st.session_state.resized_image is not None else st.session_state.loaded_image, filter_type)
                        st.session_state.filtered_image = filtered_image
                        display_message("Filter applied successfully!", type='success')
                except Exception as e:
                    display_message(f"Error applying filter: {str(e)}", type='error')
            if 'filtered_image' in st.session_state and st.session_state.filtered_image is not None:
                st.image(st.session_state.filtered_image, caption="Filtered Image")
        if st.button("Detect Objects"):
             with st.spinner("Detecting Objects..."):
                  try:
                      detections = kama_lang.context['detect_objects'](st.session_state.filtered_image if 'filtered_image' in st.session_state and st.session_state.filtered_image is not None else st.session_state.resized_image if 'resized_image' in st.session_state and st.session_state.resized_image is not None else st.session_state.loaded_image )
                      st.write("Detections:", detections)
                      display_message("Objects detected successfully!", type='success')
                  except Exception as e:
                      display_message(f"Error detecting objects: {str(e)}", type='error')