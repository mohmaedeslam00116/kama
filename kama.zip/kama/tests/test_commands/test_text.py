# kama/tests/test_commands/test_text.py

import unittest
from kama.commands.text import (
    tokenize_text,
    remove_stopwords,
    create_word_embeddings,
    sentiment_analysis
)
import numpy as np


class TestTextCommands(unittest.TestCase):
    def setUp(self):
          self.text_example = "This is a test sentence for testing purposes."
          self.tokens_example = ['This', 'is', 'a', 'test', 'sentence', 'for', 'testing', 'purposes', '.']


    def test_tokenize_text_nltk(self):
        tokens = tokenize_text(self.text_example, 'nltk')
        self.assertEqual(tokens, self.tokens_example)

    def test_tokenize_text_invalid_tokenizer(self):
         with self.assertRaises(ValueError):
            tokenize_text(self.text_example, 'invalid_tokenizer')

    def test_tokenize_text_error(self):
        self.assertIsNone(tokenize_text(None, 'nltk'))

    def test_remove_stopwords_english(self):
        filtered_tokens = remove_stopwords(self.tokens_example, 'english')
        self.assertEqual(filtered_tokens, ['test', 'sentence', 'testing', 'purposes', '.'])

    def test_remove_stopwords_invalid_language(self):
         with self.assertRaises(Exception):
           remove_stopwords(self.tokens_example, 'invalid_language')

    def test_remove_stopwords_error(self):
         self.assertIsNone(remove_stopwords(None, 'english'))


    def test_create_word_embeddings_word2vec(self):
        embeddings = create_word_embeddings(self.text_example, 'word2vec')
        self.assertTrue(isinstance(embeddings, dict))
        self.assertTrue(all(isinstance(embeddings[word], np.ndarray) for word in self.tokens_example))

    def test_create_word_embeddings_invalid_embedding_type(self):
        with self.assertRaises(ValueError):
          create_word_embeddings(self.text_example, 'invalid_embedding_type')
    
    def test_create_word_embeddings_error(self):
        self.assertIsNone(create_word_embeddings(None, 'word2vec'))

    def test_sentiment_analysis(self):
        result = sentiment_analysis(self.text_example)
        self.assertTrue(isinstance(result, list))
        self.assertTrue('label' in result[0])
        self.assertTrue('score' in result[0])
    
    def test_sentiment_analysis_error(self):
        self.assertIsNone(sentiment_analysis(None))


if __name__ == '__main__':
    unittest.main()