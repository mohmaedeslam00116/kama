# kama/tests/test_commands/__init__.py

from .test_data import *
from .test_models import *
from .test_cloud import *
from .test_text import *
from .test_image import *