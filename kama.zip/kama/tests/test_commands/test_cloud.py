# kama/tests/test_commands/test_cloud.py
import unittest
from kama.commands.cloud import upload_to_gcloud, upload_to_aws

class TestCloudCommands(unittest.TestCase):
    def test_upload_to_gcloud(self):
         # This test would require mocking the Google Cloud Storage client
         # You can add this later when you are more familiar with mocking
         # For now, we just check that it returns None (error case), when passing invalid parameters
         self.assertIsNone(upload_to_gcloud("invalid_bucket", "invalid_path"))

    def test_upload_to_aws(self):
        # This test would require mocking the boto3 s3 client
        # You can add this later when you are more familiar with mocking
        # For now, we just check that it returns None (error case), when passing invalid parameters
         self.assertIsNone(upload_to_aws("invalid_bucket", "invalid_path"))

if __name__ == '__main__':
    unittest.main()