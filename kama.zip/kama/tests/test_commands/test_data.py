# kama/tests/test_commands/test_data.py

import unittest
import numpy as np
import pandas as pd
from kama.commands.data import (
    load_data,
    analyze_data,
    load_large_data,
    process_large_data,
    get_data_shape,
    convert_to_tensor,
    plot_data,
    clean_data,
    transform_data,
    split_data,
    group_data
)
import tensorflow as tf
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.model_selection import train_test_split


class TestDataCommands(unittest.TestCase):
    def setUp(self):
        self.data = pd.DataFrame({'col1': [1, 2, 3, 4, 5], 'col2': [6, 7, 8, 9, 10], 'target': [0, 1, 0, 1, 0]})
        self.x_train_split, self.x_test_split, self.y_train_split, self.y_test_split = split_data(self.data, test_size=0.2, random_state=42)

    def test_load_data_mnist(self):
        (x_train, y_train), (x_test, y_test) = load_data("mnist")
        self.assertTrue(isinstance(x_train, np.ndarray))
        self.assertTrue(isinstance(y_train, np.ndarray))
        self.assertTrue(isinstance(x_test, np.ndarray))
        self.assertTrue(isinstance(y_test, np.ndarray))

    def test_load_data_unsupported(self):
         with self.assertRaises(ValueError):
              load_data("invalid_dataset")

    def test_analyze_data(self):
          data = np.array([1, 2, 3, 4, 5])
          mean, std = analyze_data(data)
          self.assertAlmostEqual(mean, 3.0)
          self.assertAlmostEqual(std, 1.41421356, places=7)

    def test_analyze_data_error(self):
        self.assertIsNone(analyze_data(None))

    def test_load_large_data(self):
        # إنشاء ملف بيانات وهمي
        with open("test_data.csv", "w") as f:
            f.write("col1,col2\n")
            for i in range(25000):
              f.write(f"{i},{i*2}\n")

        data_chunks = load_large_data("test_data.csv", chunksize=10000)
        self.assertTrue(data_chunks is not None)
        self.assertTrue(hasattr(data_chunks, '__iter__'))

        # تنظيف الملف الوهمي
        import os
        os.remove("test_data.csv")

    def test_load_large_data_error(self):
         self.assertIsNone(load_large_data("invalid_path.csv"))

    def test_process_large_data(self):
         # إنشاء ملف بيانات وهمي
         with open("test_data.csv", "w") as f:
              f.write("col1,col2\n")
              for i in range(25000):
                  f.write(f"{i},{i*2}\n")

         data_chunks = load_large_data("test_data.csv", chunksize=10000)
         processed_data = process_large_data(data_chunks)
         self.assertTrue(isinstance(processed_data, pd.DataFrame))

         # تنظيف الملف الوهمي
         import os
         os.remove("test_data.csv")

    def test_process_large_data_error(self):
         self.assertIsNone(process_large_data(None))


    def test_get_data_shape(self):
        data = np.array([[1, 2], [3, 4], [5, 6]])
        shape = get_data_shape(data)
        self.assertEqual(shape, (3, 2))

    def test_get_data_shape_error(self):
         self.assertIsNone(get_data_shape(None))

    def test_plot_data(self):
         data = np.array([1, 2, 3, 4, 5])
         plot_result = plot_data(data, plot_type='line')
         self.assertEqual(plot_result, 'Plot generated successfully')

    def test_plot_data_error(self):
        self.assertIsNone(plot_data(None))

    def test_convert_to_tensor(self):
         data = np.array([1, 2, 3])
         tensor = convert_to_tensor(data)
         self.assertTrue(isinstance(tensor, tf.Tensor))

    def test_convert_to_tensor_error(self):
         self.assertIsNone(convert_to_tensor(None))

    def test_clean_data_drop_na(self):
         data = pd.DataFrame({'col1': [1, 2, np.nan, 4], 'col2': [5, np.nan, 7, 8]})
         cleaned_data = clean_data(data, 'drop_na')
         self.assertEqual(len(cleaned_data), 2)

    def test_clean_data_fill_mean(self):
        data = pd.DataFrame({'col1': [1, 2, np.nan, 4], 'col2': [5, np.nan, 7, 8]})
        cleaned_data = clean_data(data, 'fill_mean')
        self.assertTrue(not cleaned_data.isnull().values.any())
        self.assertAlmostEqual(cleaned_data['col1'].iloc[2], 2.333, places=3)
        self.assertAlmostEqual(cleaned_data['col2'].iloc[1], 6.666, places=3)

    def test_clean_data_drop_duplicates(self):
        data = pd.DataFrame({'col1': [1, 2, 2, 4], 'col2': [5, 6, 6, 8]})
        cleaned_data = clean_data(data, 'drop_duplicates')
        self.assertEqual(len(cleaned_data), 3)

    def test_clean_data_invalid_strategy(self):
         with self.assertRaises(ValueError):
               clean_data(pd.DataFrame({'col1': [1, 2, 3], 'col2': [4, 5, 6]}), 'invalid_strategy')

    def test_clean_data_error(self):
        self.assertIsNone(clean_data(None, 'drop_na'))


    def test_transform_data_scale(self):
        data = pd.DataFrame({'col1': [1, 2, 3], 'col2': [4, 5, 6]})
        transformed_data = transform_data(data, ['scale'])
        self.assertTrue(isinstance(transformed_data, pd.DataFrame))
        self.assertAlmostEqual(transformed_data['col1'].iloc[0], -1.224, places=3)


    def test_transform_data_normalize(self):
         data = pd.DataFrame({'col1': [3, 4, 5], 'col2': [6, 7, 8]})
         transformed_data = transform_data(data, ['normalize'])
         self.assertTrue(isinstance(transformed_data, pd.DataFrame))
         self.assertAlmostEqual(transformed_data['col1'].iloc[0], 0.424, places=3)

    def test_transform_data_encode_categorical(self):
         data = pd.DataFrame({'col1': [1, 2, 3], 'col2': ['a', 'b', 'a']})
         transformed_data = transform_data(data, ['encode_categorical'])
         self.assertTrue('col2_a' in transformed_data.columns)
         self.assertTrue('col2_b' in transformed_data.columns)
         self.assertEqual(transformed_data['col2_a'].iloc[0], 1)
         self.assertEqual(transformed_data['col2_b'].iloc[1], 1)

    def test_transform_data_invalid_transformation(self):
         with self.assertRaises(ValueError):
             transform_data(pd.DataFrame({'col1': [1, 2, 3]}), ['invalid_transformation'])

    def test_transform_data_error(self):
        self.assertIsNone(transform_data(None, ['scale']))

    def test_split_data(self):
         data = pd.DataFrame({'col1': [1, 2, 3, 4, 5], 'col2': [6, 7, 8, 9, 10], 'target': [0, 1, 0, 1, 0]})
         x_train, x_test, y_train, y_test = split_data(data, test_size=0.2, random_state=42)
         self.assertEqual(len(x_train), 4)
         self.assertEqual(len(x_test), 1)
         self.assertTrue(isinstance(x_train, pd.DataFrame))
         self.assertTrue(isinstance(y_train, pd.Series))

    def test_split_data_error(self):
        self.assertIsNone(split_data(None, test_size=0.2, random_state=42))

    def test_split_data_target_not_found(self):
          data = pd.DataFrame({'col1': [1, 2, 3, 4, 5], 'col2': [6, 7, 8, 9, 10]})
          with self.assertRaises(ValueError):
             split_data(data, test_size=0.2, random_state=42)


    def test_group_data(self):
         data = pd.DataFrame({'col1': ['A', 'A', 'B', 'B'], 'col2': [1, 2, 3, 4], 'col3': [5, 6, 7, 8]})
         grouped_data = group_data(data, by_columns=['col1'], aggregations={'col2': 'mean', 'col3': 'sum'})
         self.assertTrue(isinstance(grouped_data, pd.DataFrame))
         self.assertEqual(grouped_data['col2'].iloc[0], 1.5)
         self.assertEqual(grouped_data['col3'].iloc[1], 15)

    def test_group_data_error(self):
        self.assertIsNone(group_data(None, by_columns=['col1'], aggregations={'col2': 'mean'}))


if __name__ == '__main__':
    unittest.main()