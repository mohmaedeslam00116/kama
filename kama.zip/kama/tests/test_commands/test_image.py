# kama/tests/test_commands/test_image.py
import unittest
import os
from PIL import Image
from kama.commands.image import (
    load_image,
    resize_image,
    apply_filter,
    detect_objects
)
class TestImageCommands(unittest.TestCase):
    def setUp(self):
        # Create a dummy image for testing
        self.image_path = "test_image.png"
        Image.new('RGB', (60, 30), color = 'red').save(self.image_path)
        self.image_example = load_image(self.image_path)

    def tearDown(self):
        # Remove dummy image after testing
        if os.path.exists(self.image_path):
            os.remove(self.image_path)

    def test_load_image(self):
        image = load_image(self.image_path)
        self.assertTrue(isinstance(image, Image.Image))

    def test_load_image_error(self):
        self.assertIsNone(load_image("invalid_path.png"))


    def test_resize_image(self):
        resized_image = resize_image(self.image_example, (100, 50))
        self.assertEqual(resized_image.size, (100, 50))

    def test_resize_image_error(self):
         self.assertIsNone(resize_image(None, (100, 50)))

    def test_apply_filter_grayscale(self):
        filtered_image = apply_filter(self.image_example, 'grayscale')
        self.assertEqual(filtered_image.mode, 'L')

    def test_apply_filter_blur(self):
        filtered_image = apply_filter(self.image_example, 'blur')
        self.assertEqual(filtered_image.mode, 'RGB')

    def test_apply_filter_edge_detection(self):
         filtered_image = apply_filter(self.image_example, 'edge_detection')
         self.assertEqual(filtered_image.mode, 'RGB')

    def test_apply_filter_invalid_filter_type(self):
        with self.assertRaises(ValueError):
           apply_filter(self.image_example, 'invalid_filter')
    
    def test_apply_filter_error(self):
        self.assertIsNone(apply_filter(None, 'grayscale'))


    def test_detect_objects_yolov8(self):
         detections = detect_objects(self.image_example)
         self.assertTrue(isinstance(detections, list))
         # No assert for specific number of items for detections as it will depends on the image that we create

    def test_detect_objects_invalid_model_name(self):
          with self.assertRaises(ValueError):
             detect_objects(self.image_example, 'invalid_model')
    
    def test_detect_objects_error(self):
         self.assertIsNone(detect_objects(None))

if __name__ == '__main__':
    unittest.main()