# kama/tests/test_commands/test_models.py

import unittest
import numpy as np
import pandas as pd
from kama.commands.models import (
    train_model,
    evaluate_model,
    save_model,
    load_model,
    predict,
    train_dnn,
    train_traditional_model,
    tune_model
)
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Flatten
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from kama.commands.data import split_data


class TestModelCommands(unittest.TestCase):
    def setUp(self):
        self.model = Sequential([
          Flatten(input_shape=(28, 28)),
          Dense(128, activation='relu'),
          Dense(10, activation='softmax')
          ])
        self.model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
        (self.x_train, self.y_train), (self.x_test, self.y_test) = load_data("mnist")
        self.data = pd.DataFrame({'col1': [1, 2, 3, 4, 5], 'col2': [6, 7, 8, 9, 10], 'target': [0, 1, 0, 1, 0]})
        self.x_train_split, self.x_test_split, self.y_train_split, self.y_test_split = split_data(self.data, test_size=0.2, random_state=42)
        self.data_train = (self.x_train_split.values, self.y_train_split.values)

    def test_evaluate_model(self):
         loss, accuracy = evaluate_model(self.model, (self.x_test, self.y_test))
         self.assertTrue(isinstance(loss, float))
         self.assertTrue(isinstance(accuracy, float))

    def test_evaluate_model_error(self):
        self.assertIsNone(evaluate_model(None,(self.x_test, self.y_test)))

    def test_save_load_model(self):
         file_path = "test_model.pkl"
         saved_file = save_model(self.model, file_path)
         loaded_model = load_model(saved_file)
         self.assertTrue(isinstance(loaded_model, Sequential))

         # تنظيف الملف الوهمي
         import os
         os.remove(file_path)

    def test_save_model_error(self):
        self.assertIsNone(save_model(None, "invalid_path.pkl"))

    def test_load_model_error(self):
        self.assertIsNone(load_model("invalid_path.pkl"))

    def test_predict(self):
         data = np.random.rand(1,28,28)
         predictions = predict(self.model, data)
         self.assertTrue(isinstance(predictions, np.ndarray))

    def test_predict_error(self):
         self.assertIsNone(predict(None,None))

    def test_train_dnn_simple_dnn(self):
          model = train_dnn(self.data_train, 'simple_dnn', {'epochs': 2})
          self.assertTrue(isinstance(model, Sequential))

    def test_train_dnn_invalid_model_type(self):
         with self.assertRaises(ValueError):
           train_dnn(self.data_train, 'invalid_model', {'epochs': 2})

    def test_train_dnn_error(self):
         self.assertIsNone(train_dnn(None, 'simple_dnn', {'epochs': 2}))


    def test_train_traditional_model_linear_regression(self):
          model = train_traditional_model(self.data_train, 'linear_regression', {})
          self.assertTrue(isinstance(model, LinearRegression))

    def test_train_traditional_model_decision_tree(self):
          model = train_traditional_model(self.data_train, 'decision_tree', {'max_depth': 2})
          self.assertTrue(isinstance(model, DecisionTreeClassifier))

    def test_train_traditional_model_random_forest(self):
          model = train_traditional_model(self.data_train, 'random_forest', {'n_estimators': 5, 'max_depth': 2})
          self.assertTrue(isinstance(model, RandomForestClassifier))

    def test_train_traditional_model_invalid_model_type(self):
         with self.assertRaises(ValueError):
            train_traditional_model(self.data_train, 'invalid_model', {})


    def test_train_traditional_model_error(self):
        self.assertIsNone(train_traditional_model(None, 'linear_regression', {}))

    def test_tune_model(self):
         model = DecisionTreeClassifier(random_state=42)
         param_grid = {'max_depth': [2, 3]}
         tuned_model = tune_model(self.data_train, model, param_grid, cv=2)
         self.assertTrue(isinstance(tuned_model, DecisionTreeClassifier))

    def test_tune_model_error(self):
        model = DecisionTreeClassifier(random_state=42)
        param_grid = {'max_depth': [2, 3]}
        self.assertIsNone(tune_model(None, model, param_grid, cv = 2))
if __name__ == '__main__':
    unittest.main()